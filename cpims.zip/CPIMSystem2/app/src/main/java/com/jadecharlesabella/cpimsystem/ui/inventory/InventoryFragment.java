package com.jadecharlesabella.cpimsystem.ui.inventory;

import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;

import androidx.annotation.NonNull;
import androidx.fragment.app.Fragment;
import androidx.lifecycle.ViewModelProvider;
import androidx.navigation.Navigation;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import com.google.android.material.floatingactionbutton.FloatingActionButton;
import com.google.android.material.snackbar.Snackbar;
import com.jadecharlesabella.cpimsystem.R;
import com.jadecharlesabella.cpimsystem.data.DatabaseHelper;
import com.jadecharlesabella.cpimsystem.data.LaptopModel;
import com.jadecharlesabella.cpimsystem.databinding.FragmentInventoryBinding;

import java.util.List;

public class InventoryFragment extends Fragment {
    private CustomAdapter customAdapter;

//    private ProductsAdapter productsAdapter;
    private FragmentInventoryBinding binding;

    public View onCreateView(@NonNull LayoutInflater inflater,
                             ViewGroup container, Bundle savedInstanceState) {


        InventoryViewModel inventoryViewModel =
                new ViewModelProvider(this).get(InventoryViewModel.class);



        binding = FragmentInventoryBinding.inflate(inflater, container, false);
        View root = binding.getRoot();

        final RecyclerView recyclerView = root.findViewById(R.id.recyclerView);
        DatabaseHelper db = new DatabaseHelper(root.getContext());
        List<LaptopModel> data = db.getAllLaptops();
        customAdapter = new CustomAdapter(
                data,
                new CustomAdapter.OnItemClickListener() {
                    @Override
                    public void onItemClick(LaptopModel item) {
                        Bundle bundle = new Bundle();
                        bundle.putInt("productId", item.productId);
                        Navigation.findNavController(root).navigate(R.id.nav_edit_product, bundle);
                    }
                },
                new CustomAdapter.OnFaveClickListener() {
                    @Override
                    public void onItemClick(LaptopModel item, int position) {
                        db.updateFavorite(item.productId, item.favorite == 0 ? 1 : 0);
                        data.set(position, new LaptopModel(item.productId, item.productName,
                                item.price, item.description, item.dateDelivered, item.dateReceived, item.image,
                                item.favorite == 0 ? 1 : 0));
                        customAdapter.notifyDataSetChanged();
                        Snackbar.make(root, item.productName + " has been " + (item.favorite == 0 ? "added" : "removed") + " to your Favorites.", Snackbar.LENGTH_LONG).show();
                    }
                },

                root.getContext());
        recyclerView.setLayoutManager(new LinearLayoutManager(root.getContext()));
        recyclerView.setAdapter(customAdapter);


        FloatingActionButton fabAddproduct = root.findViewById(R.id.fabAddProduct);
        fabAddproduct.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Navigation.findNavController(root).navigate(R.id.nav_add_product);
            }
        });
        return root;
    }

    @Override
    public void onDestroyView() {
        super.onDestroyView();
        binding = null;
    }
}