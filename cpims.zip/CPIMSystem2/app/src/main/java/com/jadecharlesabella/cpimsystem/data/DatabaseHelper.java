package com.jadecharlesabella.cpimsystem.data;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteException;
import android.database.sqlite.SQLiteOpenHelper;
import android.os.Build;
import android.util.Log;

import java.io.File;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.util.ArrayList;
import java.util.List;

public class DatabaseHelper extends SQLiteOpenHelper {

    private static String DB_PATH = "/data/data/com.jadecharlesabella.cpimsystem/databases/";

    private static String DB_NAME = "Products.db";

    private SQLiteDatabase myDatabase;

    private final Context myContext;


    public DatabaseHelper(Context context) {
        super(context, DB_NAME, null, 1);
        this.myContext = context;
    }

    @Override
    public void onOpen(SQLiteDatabase db) {
        super.onOpen(db);
        db.disableWriteAheadLogging();
    }


    public void createDataBase() throws IOException {
        boolean dbExist = checkDataBase();

        if (dbExist) {
            //do nothing - database already exist
            Log.i("DatabaseHelper", "DB is existing. NOT COPYING");
        } else {
            //By calling this method an empty database will be created into the default system path
            //of your application so we are gonna be able to overwrite that database with our database.
            this.getReadableDatabase();
            try {
                copyDataBase();
            } catch (IOException e) {
                Log.e("DatabaseHelper", e.getMessage());
                throw new Error("Error copying database");

            }
        }

    }

    private boolean checkDataBase() {

        SQLiteDatabase checkDB = null;

        try {
            String myPath = DB_PATH + DB_NAME;
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.P) {
                File dbFile = myContext.getDatabasePath(DB_NAME);
                myPath = dbFile.getPath();
                Log.i("DatabaseHelper", "here1: " + myPath);

            } else {
                myPath = DB_PATH + DB_NAME;
                Log.i("DatabaseHelper", "here2: " + myPath);
            }
            checkDB = SQLiteDatabase.openDatabase(myPath, null, SQLiteDatabase.OPEN_READWRITE | SQLiteDatabase.NO_LOCALIZED_COLLATORS);

        } catch (SQLiteException e) {

            Log.e("DatabaseHelper", e.getLocalizedMessage());

        }

        if (checkDB != null) {

            checkDB.close();

        }

        return checkDB != null ? true : false;
    }

    private  void copyDataBase() throws IOException {

        Log.i("DatabaseHelper", "DB is not existing. COPYING");
        InputStream myInput =myContext.getAssets().open(DB_NAME);

        String outFileName = DB_PATH + DB_NAME;

        OutputStream myOutput = new FileOutputStream(outFileName);

        //transfer bytes from the inputfile to the outputfile
        byte[] buffer = new byte[1024];
        int length;
        while ((length = myInput.read(buffer)) > 0) {
            myOutput.write(buffer, 0, length);
        }

        myOutput.flush();
        myOutput.close();
        myInput.close();

    }

    @Override
    public synchronized void close() {
        if (myDatabase != null)
            myDatabase.close();
        super.close();
    }

    @Override
    public void onCreate(SQLiteDatabase db) {

    }

    @Override
    public void onUpgrade(SQLiteDatabase db, int oldVersion, int newVersion) {

    }

    public List<LaptopModel> getAllLaptops() {
        SQLiteDatabase db = this.getWritableDatabase();
        List<LaptopModel> data = new ArrayList<>();

        Cursor cursor;

        try {
            cursor = db.query("Products", null, null, null, null, null, null);
            while (cursor.moveToNext()) {
                LaptopModel products = new LaptopModel(cursor.getInt(0), cursor.getString(1),
                        cursor.getString(2), cursor.getString(3), cursor.getString(4),
                        cursor.getString(5), cursor.getString(6), cursor.getInt(7));
                data.add(products);
            }
            Log.i("DatabaseHelper", "" + data);
        } catch (Exception e) {
            Log.e("DatabaseHelper", "" + e.getLocalizedMessage());
        }

        return data;
    }
        public LaptopModel getNote(int productId){
            SQLiteDatabase db = this.getWritableDatabase();
            LaptopModel product = null;

            Cursor cursor;

            try{
                cursor = db.query("Products", null, "productId = ?",
                        new String[]{"" + productId}, null, null,null);
                cursor.moveToFirst();
                product = new LaptopModel(cursor.getInt(0), cursor.getString(1),
                        cursor.getString(2),cursor.getString(3),cursor.getString(4),
                        cursor.getString(5),cursor.getString(6),cursor.getInt(7));
                Log.i("DatabaseHelper", "" + product);
            }catch(Exception e){
                Log.e("DatabaseHelper", "" + e.getLocalizedMessage());
            }
            return product;
        }
    public int updateProduct(int productId, String title, String desc){
        int result = -1;
        SQLiteDatabase db = this.getWritableDatabase();
        ContentValues cv = new ContentValues();
        cv.put("title", title);
        cv.put("description", desc);
        try {
            result = db.update("Products", cv, "productId = ?", new String[]{"" + productId});
        }catch (Exception e){
            Log.e("DatabaseHelper", "" + e.getLocalizedMessage());
        }
        return result;
    }
    public long addProduct(String title, String desc){
        long result = -1;
        SQLiteDatabase db = this.getWritableDatabase();
        ContentValues cv = new ContentValues();
        cv.put("title", title);
        cv.put("description", desc);
        result = db.insert("Products", null, cv);
        return result;
    }
    public void deleteProduct(int productId){
        SQLiteDatabase db = this.getWritableDatabase();
        ContentValues cv = new ContentValues();
        db.delete("Products", "productId = ?", new String[]{"" + productId});
    }


    public void updateFavorite(int productId, int value){
        SQLiteDatabase db = this.getWritableDatabase();
        ContentValues cv = new ContentValues();
        cv.put("favorites", value);
        try {
            db.update("Products", cv, "productId = ?", new String[]{"" + productId});
        }catch (Exception e){
            Log.e("DatabaseHelper", "" + e.getLocalizedMessage());
        }
    }

//    public List<LaptopModel> getAllProducts(){
//
//    SQLiteDatabase db = this.getWritableDatabase();
//    List<LaptopModel> data = new ArrayList<>();
//
//    Cursor cursor;
//
//    try{
//        cursor = db.query("Products", null, null, null, null, null,null);
//        while(cursor.moveToNext()){
//        LaptopModel productsLaptop = new LaptopModel(cursor.getInt(0),cursor.getInt(1),
//                cursor.getInt(2),cursor.getInt(3),cursor.getInt(4),
//                cursor.getInt(5),cursor.getInt(6),cursor.getInt(7));

//        }
//    }

//    }

}
