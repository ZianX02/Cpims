package com.jadecharlesabella.cpimsystem.data;

import androidx.annotation.NonNull;

public class LaptopModel {

    public int productId;
    public String productName;
    public String price;
    public String description;
    public String dateDelivered;
    public String dateReceived;
    public String image;
    public int favorite;




    public LaptopModel(int productId, String productName, String price, String description,
                       String dateDelivered, String dateReceived, String image, int favorite){

        this.productId = productId;
        this.productName = productName;
        this.price = price;
        this.description = description;
        this.dateDelivered = dateDelivered;
        this.dateReceived = dateReceived;
        this.image = image;
        this.favorite = favorite;


    }

    @NonNull
    @Override
    public  String toString(){
        return "LaptopModel{" +
                "productId=" + productId +
                ", productName='"+productName +'\''+
                ", price='"+price + '\''+
                ", description+'"+ description + '\'' +
                ", dateDelivered+'"+ dateDelivered + '\''+
                ", dateReceive'" + dateReceived + '\'' +
                ", image'" + image + '\'' +
                ", favorite'"+ favorite + '\'' +
                '}';


    }

}
