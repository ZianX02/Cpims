package com.jadecharlesabella.cpimsystem.ui.home;

import static android.R.layout.simple_list_item_1;

import android.annotation.SuppressLint;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.GridView;
import android.widget.ListView;
import android.widget.RelativeLayout;
import android.widget.SearchView;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.fragment.app.Fragment;
import androidx.lifecycle.ViewModelProvider;

import com.jadecharlesabella.cpimsystem.R;
import com.jadecharlesabella.cpimsystem.databinding.FragmentHomeBinding;

import java.sql.Connection;
import java.util.ArrayList;

public class HomeFragment extends Fragment {

    ArrayList<String> arrayList;
    ArrayAdapter<String> adapter;
    private FragmentHomeBinding binding;

    public View onCreateView(@NonNull LayoutInflater inflater,
                             ViewGroup container, Bundle savedInstanceState) {
        HomeViewModel homeViewModel =
                new ViewModelProvider(this).get(HomeViewModel.class);

        binding = FragmentHomeBinding.inflate(inflater, container, false);
        View root = binding.getRoot();

        final SearchView searchView = root.findViewById(R.id.searchView);
//        Button btnLoad = root.findViewById(R.id.button_load);
//        GridView gridView = root.findViewById(R.id.gridView);
        ListView listView = root.findViewById(R.id.listView);

//        btnLoad.setOnClickListener(new View.OnClickListener() {
//            @Override
//            public void onClick(View v) {
//
//            }
//        });

        listView.setVisibility(View.GONE);

        arrayList = new ArrayList<>();
        arrayList.add("Dell");
        arrayList.add("Acer");
        arrayList.add("Microsoft");
        arrayList.add("Huawei");
        arrayList.add("Asus");
        arrayList.add("Lenovo");
        arrayList.add("Samsung");
        arrayList.add("MSI");
        arrayList.add("Razer");
        arrayList.add("ROG");
        arrayList.add("Mac");
        arrayList.add("Legion");
        arrayList.add("Omen");
        arrayList.add("HP");
        arrayList.add("LG");

        adapter = new ArrayAdapter<>(getActivity(), android.R.layout.simple_list_item_1, arrayList);

        listView.setAdapter(adapter);

        searchView.setOnQueryTextListener(new SearchView.OnQueryTextListener() {
            @Override
            public boolean onQueryTextSubmit(String query) {
                return false;
            }

            @Override
            public boolean onQueryTextChange(String s) {

                if (s.isEmpty()) {
                    listView.setVisibility(View.GONE);
                } else {
                    listView.setVisibility(View.VISIBLE);
                    adapter.getFilter().filter(s);
                }
                return false;
            }
        });

        return root;


    }



    @Override
    public void onDestroyView() {
        super.onDestroyView();
        binding = null;
    }
}